require('foo')

foo.doSomething()

