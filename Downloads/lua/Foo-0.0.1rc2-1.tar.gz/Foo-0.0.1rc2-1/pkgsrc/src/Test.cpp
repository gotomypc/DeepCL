#include <iostream>

#include "Test.h"

using namespace std;

void doSomething() {
    cout << "Test.doSomething() 0.7" << endl;
}
void doSomething2() {
    cout << "Test.doSomething2()" << endl;
}
void doSomething3() {
    cout << "Test.doSomething3()" << endl;
}
void doSomething4() {
    cout << "Test.doSomething4()" << endl;
}

