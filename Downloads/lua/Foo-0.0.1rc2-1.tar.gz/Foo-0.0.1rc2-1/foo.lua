local P = {}
foo = P

local print = print

setfenv(1, P )

function doSomething()
    print('hi')
end

