require('Test')
Test.doSomething()
Test.doSomething2()
Test.doSomething3()
Test.doSomething4()

