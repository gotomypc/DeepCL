// clewTest.cpp : Defines the entry point for the console application.
//

#include "clew.h"

int main(int argc, char* argv[])
{
	clewInit();
	return 0;
}

